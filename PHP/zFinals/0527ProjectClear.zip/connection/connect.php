<?php
$connect = mysqli_connect('localhost', 'root', '', 'final');
if (!$connect) {
    die ('Error connect to DataBase');
}
